const $ = (id) => document.getElementById(id);
let mode = "login";
const authPanel = $("auth-panel");
const dashboard = $("dashboard");
const welcome = $("welcome");

function message(text, isError = false) {
  $("auth-message").textContent = text || "";
  $("auth-message").classList.toggle("error", Boolean(isError));
}
function setMode(next) {
  mode = next;
  $("tab-login").classList.toggle("active", mode === "login");
  $("tab-register").classList.toggle("active", mode === "register");
  $("submit-auth").textContent = mode === "login" ? "Entrar a Stargame Elite" : "Crear mi cuenta";
  $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
  $("password-help").classList.toggle("hidden", mode !== "register");
  message("");
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "No se pudo completar la operación.");
  return data;
}
function showDashboard(user) {
  authPanel.classList.add("hidden");
  welcome.classList.add("hidden");
  dashboard.classList.remove("hidden");
  $("user-name").textContent = user.username;
  $("profile-name").textContent = "@" + user.username;
  loadActivity();
}
function showLoggedOut() {
  dashboard.classList.add("hidden");
  authPanel.classList.remove("hidden");
  welcome.classList.remove("hidden");
}
$("tab-login").addEventListener("click", () => setMode("login"));
$("tab-register").addEventListener("click", () => setMode("register"));

$("auth-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  message("");
  const button = $("submit-auth");
  button.disabled = true;
  const username = $("username").value.trim();
  const password = $("password").value;
  try {
    const data = await api(mode === "login" ? "/api/login" : "/api/register", {
      method: "POST", body: JSON.stringify({ username, password })
    });
    showDashboard(data.user);
  } catch (error) {
    message(error.message, true);
  } finally {
    button.disabled = false;
  }
});
$("logout").addEventListener("click", async () => {
  try { await api("/api/logout", { method: "POST", body: "{}" }); }
  finally { showLoggedOut(); }
});
async function recordActivity(eventType, details) {
  await api("/api/activity", { method: "POST", body: JSON.stringify({ eventType, details }) });
}
async function loadActivity() {
  const container = $("activity-list");
  try {
    const data = await api("/api/activity");
    if (!data.activity.length) {
      container.innerHTML = '<p class="muted">Todavía no hay actividad registrada.</p>';
      return;
    }
    container.replaceChildren();
    for (const item of data.activity) {
      const row = document.createElement("div");
      row.className = "activity-item";
      const title = document.createElement("span");
      title.textContent = item.event_type === "demo_game_opened" ? `Abrió ${item.details || "un juego demo"}` : "Consultó su perfil";
      const date = document.createElement("small");
      date.textContent = item.created_at;
      row.append(title, date);
      container.append(row);
    }
  } catch {
    container.innerHTML = '<p class="muted">No se pudo cargar la actividad.</p>';
  }
}
$("refresh-activity").addEventListener("click", loadActivity);
document.querySelectorAll("[data-game]").forEach((button) => {
  button.addEventListener("click", async () => {
    const game = button.dataset.game;
    try {
      await recordActivity("demo_game_opened", game);
      $("game-message").textContent = `${game}: esta tarjeta es una demostración visual. La integración de juegos autorizados se agregará en una etapa posterior.`;
      $("game-message").classList.remove("hidden");
      loadActivity();
    } catch (error) {
      $("game-message").textContent = error.message;
      $("game-message").classList.remove("hidden");
    }
  });
});
api("/api/me").then(({ user }) => user ? showDashboard(user) : showLoggedOut()).catch(showLoggedOut);
