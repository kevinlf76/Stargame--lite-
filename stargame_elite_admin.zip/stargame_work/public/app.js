const $ = (id) => document.getElementById(id);
let authMode = "login";
let currentUser = null;
let toastTimer;

function toast(text) {
  const el = $("toast");
  el.textContent = text;
  el.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add("hidden"), 3500);
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "No se pudo completar la solicitud.");
  return data;
}
function openAuth(mode = "login") {
  setAuthMode(mode);
  $("auth-modal").classList.remove("hidden");
  document.body.style.overflow = "hidden";
  setTimeout(() => $("username").focus(), 40);
}
function closeAuth() {
  $("auth-modal").classList.add("hidden");
  document.body.style.overflow = "";
  $("auth-message").textContent = "";
  $("auth-form").reset();
}
function setAuthMode(mode) {
  authMode = mode;
  $("login-tab").classList.toggle("active", mode === "login");
  $("register-tab").classList.toggle("active", mode === "register");
  $("modal-title").textContent = mode === "login" ? "Ingresá a tu cuenta" : "Creá tu cuenta";
  $("submit-auth").textContent = mode === "login" ? "Ingresar" : "Crear cuenta";
  $("password").autocomplete = mode === "login" ? "current-password" : "new-password";
  $("password-hint").classList.toggle("hidden", mode !== "register");
  $("auth-message").textContent = "";
  $("auth-message").classList.remove("error");
}
function showUser(user) {
  currentUser = user;
  $("header-login").classList.add("hidden");
  $("header-register").classList.add("hidden");
  $("header-user").classList.remove("hidden");
  $("header-user").textContent = "✦ " + user.username;
  $("strip-register").textContent = "Mi cuenta: " + user.username;
  $("welcome-strip").querySelector("strong").textContent = "¡Bienvenido, " + user.username + "!";
  $("welcome-strip").querySelector("p").textContent = "Tu sesión está activa. Tu actividad de demostración se guarda en tu cuenta.";
  $("strip-register").onclick = () => toast("Sesión iniciada como " + user.username + ".");
}
function showLoggedOut() {
  currentUser = null;
  $("header-login").classList.remove("hidden");
  $("header-register").classList.remove("hidden");
  $("header-user").classList.add("hidden");
  $("welcome-strip").querySelector("strong").textContent = "Bienvenido a Stargame Elite";
  $("welcome-strip").querySelector("p").textContent = "Creá tu cuenta para guardar tu perfil y tu actividad.";
  $("strip-register").textContent = "Crear cuenta gratis";
  $("strip-register").onclick = () => openAuth("register");
}
async function openGame(name) {
  if (!currentUser) {
    toast("Creá una cuenta o ingresá para guardar tu actividad.");
    openAuth("register");
    return;
  }
  try {
    await api("/api/activity", { method: "POST", body: JSON.stringify({ eventType: "demo_game_opened", details: name }) });
    toast(name + ": demostración visual. No permite apostar.");
  } catch (err) {
    toast(err.message);
  }
}
function applyFilters() {
  const query = $("search").value.trim().toLowerCase();
  const selectedSide = document.querySelector(".side-link.selected");
  const category = selectedSide?.dataset.category || "todos";
  const section = selectedSide?.dataset.section || "inicio";
  let visible = 0;
  document.querySelectorAll(".game-card").forEach((card) => {
    const matchesQuery = card.dataset.game.toLowerCase().includes(query);
    const matchesCategory = category === "todos" || card.dataset.category === category;
    const matchesSection = section === "inicio" || section === "favoritos" || card.dataset.section === section;
    const show = matchesQuery && matchesCategory && matchesSection;
    card.classList.toggle("hidden", !show);
    if (show) visible++;
  });
  $("empty-games").classList.toggle("hidden", visible > 0);
  $("game-count").textContent = visible + (visible === 1 ? " juego demo" : " juegos demo");
  const titles = {inicio:"Juegos destacados",populares:"Juegos populares",nuevos:"Nuevos juegos",favoritos:"Mis favoritos"};
  $("catalog-title").textContent = category !== "todos" ? ({slots:"Slots de demostración",mesa:"Juegos de mesa",casual:"Juegos casuales"}[category] || "Todos los juegos") : (titles[section] || "Juegos destacados");
}
$("header-login").addEventListener("click", () => openAuth("login"));
$("header-register").addEventListener("click", () => openAuth("register"));
$("header-user").addEventListener("click", async () => {
  if (!currentUser) return;
  try {
    await api("/api/logout", { method:"POST", body:"{}" });
    showLoggedOut();
    toast("Cerraste sesión correctamente.");
  } catch (err) { toast(err.message); }
});
$("banner-account").addEventListener("click", () => currentUser ? toast("Tu sesión está activa como " + currentUser.username + ".") : openAuth("login"));
$("banner-play").addEventListener("click", () => $("games").scrollIntoView({ behavior:"smooth", block:"start" }));
$("footer-login").addEventListener("click", () => openAuth("login"));
$("strip-register").addEventListener("click", () => openAuth("register"));
$("modal-close").addEventListener("click", closeAuth);
$("auth-modal").addEventListener("click", (event) => { if (event.target === $("auth-modal")) closeAuth(); });
document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeAuth(); });
$("login-tab").addEventListener("click", () => setAuthMode("login"));
$("register-tab").addEventListener("click", () => setAuthMode("register"));
$("auth-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = $("submit-auth");
  button.disabled = true;
  $("auth-message").textContent = "";
  $("auth-message").classList.remove("error");
  try {
    const data = await api(authMode === "login" ? "/api/login" : "/api/register", {
      method:"POST",
      body:JSON.stringify({ username:$("username").value.trim(), password:$("password").value })
    });
    showUser(data.user);
    closeAuth();
    toast(authMode === "login" ? "Bienvenido de nuevo, " + data.user.username + "." : "Cuenta creada correctamente. ¡Bienvenido!");
  } catch (err) {
    $("auth-message").textContent = err.message;
    $("auth-message").classList.add("error");
  } finally { button.disabled = false; }
});
$("search").addEventListener("input", applyFilters);
document.querySelectorAll(".side-link").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".side-link").forEach((b) => b.classList.remove("selected"));
    button.classList.add("selected");
    applyFilters();
    $("sidebar").classList.remove("open");
  });
});
document.querySelectorAll(".game-card").forEach((card) => card.addEventListener("click", () => openGame(card.dataset.game)));
$("mobile-menu").addEventListener("click", () => $("sidebar").classList.toggle("open"));
document.addEventListener("click", (event) => {
  if (window.innerWidth <= 700 && !$("sidebar").contains(event.target) && !$("mobile-menu").contains(event.target)) $("sidebar").classList.remove("open");
});
api("/api/me").then(({user}) => user ? showUser(user) : showLoggedOut()).catch(showLoggedOut);
